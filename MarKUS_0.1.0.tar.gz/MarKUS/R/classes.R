setClassUnion("dfOrVec", c("data.frame", "vector"))
